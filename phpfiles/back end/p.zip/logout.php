<?php
<<<<<<< HEAD
session_start();
session_unset();
session_destroy();
header("Location: login.php?error=0");	
=======

>>>>>>> 7438eb5adbfc970d96723886c891347c80cff06f
?>