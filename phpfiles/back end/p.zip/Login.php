<<<<<<< HEAD
<?php
 
 session_start();
$email= $_REQUEST["email"];

$password= $_REQUEST["password"];
if($email=="ayman@gmail.com" && $password=="123")
{
	$_SESSION["email"]=$email;
	echo "user name and password are ok";
}
else
{
	header("location:login.php");
}
?>
=======
>>>>>>> 7438eb5adbfc970d96723886c891347c80cff06f
